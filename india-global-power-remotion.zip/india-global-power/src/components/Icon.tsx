import React from "react";

export type IconKind = "market" | "digital" | "factory" | "person" | "coin" | "bridge" | "import";

export const Icon: React.FC<{ kind: IconKind; size?: number; color: string }> = ({ kind, size = 84, color }) => {
  const common = {
    fill: "none", stroke: color, strokeWidth: 3.5,
    strokeLinecap: "round", strokeLinejoin: "round",
  } as const;
  let body: React.ReactNode = null;
  switch (kind) {
    case "market":
      body = (
        <>
          <rect x="10" y="36" width="10" height="20" {...common} />
          <rect x="27" y="24" width="10" height="32" {...common} />
          <rect x="44" y="12" width="10" height="44" {...common} />
          <path d="M6 59 H58" {...common} />
        </>
      );
      break;
    case "digital":
      body = (
        <>
          <circle cx="12" cy="32" r="6" {...common} />
          <circle cx="52" cy="14" r="6" {...common} />
          <circle cx="52" cy="50" r="6" {...common} />
          <circle cx="32" cy="32" r="5" {...common} />
          <path d="M18 32 H27 M36 29 L47 17 M36 35 L47 47" {...common} />
        </>
      );
      break;
    case "factory":
      body = <path d="M8 56 V30 L24 40 V30 L40 40 V14 H52 V56 Z M40 56 V48" {...common} />;
      break;
    case "person":
      body = (
        <>
          <circle cx="32" cy="20" r="10" {...common} />
          <path d="M12 56 C12 38 52 38 52 56" {...common} />
        </>
      );
      break;
    case "coin":
      body = (
        <>
          <circle cx="32" cy="32" r="22" {...common} />
          <path d="M32 18 V46 M24 26 H40 M24 38 H40" {...common} />
        </>
      );
      break;
    case "bridge":
      body = (
        <>
          <path d="M4 46 H60" {...common} />
          <path d="M10 46 Q32 4 54 46" {...common} />
          <path d="M21 46 V28 M32 46 V22 M43 46 V28" {...common} />
        </>
      );
      break;
    case "import":
      body = (
        <>
          <path d="M32 6 V34 M20 24 L32 36 L44 24" {...common} />
          <path d="M10 44 H54 V58 H10 Z" {...common} />
        </>
      );
      break;
  }
  return (
    <svg width={size} height={size} viewBox="0 0 64 64">
      {body}
    </svg>
  );
};
