import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { clamp } from "./Text";

// Wireframe globe with flowing connection arcs (pure SVG, rotates continuously)
export const Globe: React.FC<{ size: number }> = ({ size }) => {
  const frame = useCurrentFrame();
  const c = size / 2;
  const R = size * 0.46;
  const rot = frame / 90;
  const merid = [0, 1, 2, 3, 4, 5].map((k) => Math.abs(Math.cos(rot + (k * Math.PI) / 6)) * R);
  const lats = [-60, -30, 0, 30, 60].map((d) => ({
    r: Math.cos((d * Math.PI) / 180) * R,
    y: c - Math.sin((d * Math.PI) / 180) * R,
  }));
  const ix = c + R * 0.28;
  const iy = c - R * 0.05;
  const targets = [
    [c - R * 0.75, c - R * 0.2],
    [c + R * 0.8, c - R * 0.35],
    [c - R * 0.5, c + R * 0.55],
    [c + R * 0.55, c + R * 0.6],
  ];
  const ripple = (frame % 60) / 60;
  const arcIn = interpolate(frame, [20, 60], [0, 1], { easing: theme.ease.out, ...clamp });
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <radialGradient id="globeFill">
          <stop offset="55%" stopColor={theme.colors.accent} stopOpacity="0" />
          <stop offset="100%" stopColor={theme.colors.accent} stopOpacity="0.22" />
        </radialGradient>
      </defs>
      <circle cx={c} cy={c} r={R} fill="url(#globeFill)" stroke={theme.colors.accent} strokeOpacity="0.55" strokeWidth="2.5" />
      {lats.map((l, i) => (
        <ellipse key={`la${i}`} cx={c} cy={l.y} rx={l.r} ry={l.r * 0.16} fill="none" stroke={theme.colors.accent} strokeOpacity="0.25" strokeWidth="1.5" />
      ))}
      {merid.map((m, i) => (
        <ellipse key={`me${i}`} cx={c} cy={c} rx={m} ry={R} fill="none" stroke={theme.colors.accent} strokeOpacity="0.22" strokeWidth="1.5" />
      ))}
      {targets.map(([tx, ty], i) => {
        const mx = (ix + tx) / 2;
        const my = Math.min(iy, ty) - R * 0.35;
        return (
          <g key={`ar${i}`} opacity={arcIn}>
            <path
              d={`M ${ix} ${iy} Q ${mx} ${my} ${tx} ${ty}`}
              fill="none" stroke={theme.colors.text} strokeOpacity="0.75" strokeWidth="2.5"
              strokeDasharray="10 14" strokeDashoffset={-frame * 1.6} strokeLinecap="round"
            />
            <circle cx={tx} cy={ty} r="7" fill={theme.colors.accent} />
          </g>
        );
      })}
      <circle cx={ix} cy={iy} r={12 + ripple * 46} fill="none" stroke={theme.colors.text} strokeOpacity={(1 - ripple) * 0.6} strokeWidth="2.5" />
      <circle cx={ix} cy={iy} r="10" fill={theme.colors.text} />
    </svg>
  );
};
