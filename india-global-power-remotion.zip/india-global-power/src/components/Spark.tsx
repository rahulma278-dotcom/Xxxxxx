import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

// Radial mark with staggered rays (used when no logo file is supplied)
export const Spark: React.FC<{ size: number; delay?: number }> = ({ size, delay = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const rays = 12;
  const pop = spring({ frame: frame - delay, fps, config: theme.spring.bouncy });
  const spin = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const breathe = 1 + Math.sin(frame / 22) * 0.02;
  return (
    <div
      style={{
        position: "relative", width: size, height: size,
        transform: `scale(${Math.max(0, pop) * breathe}) rotate(${interpolate(spin, [0, 1], [-120, 0])}deg)`,
        filter: `drop-shadow(0 0 ${size * 0.25}px ${theme.colors.glow})`,
      }}
    >
      {Array.from({ length: rays }).map((_, i) => {
        const p = spring({ frame: frame - delay - i * 1.2, fps, config: theme.spring.snappy });
        return (
          <div
            key={i}
            style={{
              position: "absolute", left: "50%", top: "50%",
              width: size * 0.07, height: size * 0.42 * Math.max(0, p),
              background: theme.colors.primary, borderRadius: size,
              transformOrigin: "50% 0%",
              transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.08}px)`,
            }}
          />
        );
      })}
    </div>
  );
};
