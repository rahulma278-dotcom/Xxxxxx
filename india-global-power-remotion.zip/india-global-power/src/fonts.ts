// Hind: Devanagari (हिन्दी) + Latin in one family, so mixed Hindi/English words match.
import { loadFont } from "@remotion/google-fonts/Hind";

export const { fontFamily } = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["devanagari", "latin"],
});
