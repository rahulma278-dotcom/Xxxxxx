import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Icon, IconKind } from "./Icon";
import { Pop, clamp } from "./Text";

// Glass list card. Amber "focus" overlay is active only between activeFrom..activeTo
// (one hero-coloured element at a time).
export const ListCard: React.FC<{
  top: number; delay: number; icon: IconKind; label: string;
  activeFrom: number; activeTo: number; index: number; height?: number; labelSize?: number;
}> = ({ top, delay, icon, label, activeFrom, activeTo, index, height = 200, labelSize = 56 }) => {
  const frame = useCurrentFrame();
  const amt = interpolate(frame, [activeFrom, activeFrom + 6, activeTo, activeTo + 10], [0, 1, 1, 0], clamp);
  const float = Math.sin((frame + index * 14) / 28) * 4;
  return (
    <div style={{ position: "absolute", left: 110, top: top + float, width: 860, height }}>
      <Pop delay={delay} x={80} y={20} style={{ width: "100%", height: "100%" }}>
        <div
          style={{
            position: "relative", width: "100%", height: "100%", borderRadius: 36,
            background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassBorder}`,
            boxShadow: "0 40px 80px -30px rgba(0,0,0,0.7)",
            display: "flex", alignItems: "center", gap: 34, padding: "0 44px", boxSizing: "border-box",
          }}
        >
          <div style={{ position: "relative", width: 84, height: 84, flexShrink: 0 }}>
            <Icon kind={icon} color={theme.colors.accent} />
            <div style={{ position: "absolute", inset: 0, opacity: amt, filter: `drop-shadow(0 0 18px ${theme.colors.glow})` }}>
              <Icon kind={icon} color={theme.colors.primary} />
            </div>
          </div>
          <div
            style={{
              fontFamily: theme.fonts.display, fontSize: labelSize, fontWeight: 700, lineHeight: 1.3,
              letterSpacing: 0, color: theme.colors.text,
            }}
          >
            {label}
          </div>
          <div
            style={{
              position: "absolute", inset: 0, borderRadius: 36, opacity: amt,
              border: `2.5px solid ${theme.colors.primary}`,
              boxShadow: `0 0 60px ${theme.colors.glow}`, pointerEvents: "none",
            }}
          />
        </div>
      </Pop>
    </div>
  );
};
