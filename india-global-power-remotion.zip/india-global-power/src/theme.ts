// theme.ts — single source of truth. No inline colors/easings/springs in components.
import { Easing } from "remotion";
import { fontFamily } from "./fonts";

export const theme = {
  video: { width: 1080, height: 1920, fps: 30 },
  colors: {
    bg: "#060A12",
    bgAlt: "#0D1424",
    primary: "#F5A623", // hero amber — highlights only
    accent: "#5BA8FF", // ice blue — structure, lines, icons
    text: "#F2F5FA",
    textDim: "#8E9AB0",
    glow: "rgba(245, 166, 35, 0.45)",
    glass: "rgba(255, 255, 255, 0.05)",
    glassBorder: "rgba(255, 255, 255, 0.11)",
    line: "rgba(91, 168, 255, 0.38)",
  },
  fonts: { display: fontFamily, body: fontFamily },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    wobble: { damping: 6, stiffness: 55, mass: 1 },
  },
  flags: {
    // Studio-only preview of public/voiceover.mp3. NEVER included in renders.
    previewVoiceover: true,
    // Put your logo in public/ and set e.g. "logo.png". null = text-only wordmark.
    logoFile: null as string | null,
  },
} as const;
