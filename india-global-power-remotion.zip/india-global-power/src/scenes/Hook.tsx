import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { at } from "../timing";
import { Globe } from "../components/Globe";
import { Phase, Pop, SceneShell, Stack, WordReveal, clamp, usePop } from "../components/Text";

const T = (t: number) => at(0, t);

const NumberBadge: React.FC<{ n: string; delay: number }> = ({ n, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const ring = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const breathe = 1 + Math.sin((frame + delay) / 24) * 0.02;
  return (
    <Pop delay={delay} y={50} from={0.8}>
      <div style={{ position: "relative", width: 190, height: 190, transform: `scale(${breathe})` }}>
        <svg width={190} height={190} viewBox="0 0 190 190" style={{ position: "absolute", inset: 0 }}>
          <circle cx="95" cy="95" r="86" fill={theme.colors.glass} stroke={theme.colors.glassBorder} strokeWidth="2" />
          <circle
            cx="95" cy="95" r="86" fill="none" stroke={theme.colors.accent} strokeWidth="5" strokeLinecap="round"
            pathLength={1} strokeDasharray="1" strokeDashoffset={1 - Math.min(1, Math.max(0, ring))}
            transform="rotate(-90 95 95)"
          />
        </svg>
        <div
          style={{
            position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: theme.fonts.display, fontSize: 76, fontWeight: 700, letterSpacing: 0,
            color: theme.colors.text, fontVariantNumeric: "tabular-nums",
          }}
        >
          {n}
        </div>
      </div>
    </Pop>
  );
};

const GdpBlock: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = usePop(14, theme.spring.bouncy);
  const strike = spring({ frame: frame - 36, fps, config: theme.spring.smooth });
  const dim = interpolate(frame, [38, 52], [1, 0.4], { easing: theme.ease.out, ...clamp });
  return (
    <>
      <Stack top={900} gap={0}>
        <WordReveal text="इसका जवाब सिर्फ" size={62} weight={500} color={theme.colors.textDim} />
      </Stack>
      <div style={{ position: "absolute", left: 0, right: 0, top: 960, display: "flex", justifyContent: "center" }}>
        <div
          style={{
            fontFamily: theme.fonts.display, fontSize: 240, fontWeight: 700, lineHeight: 1.15, letterSpacing: 0,
            color: theme.colors.text, opacity: Math.min(1, Math.max(0, p)) * dim,
            transform: `scale(${0.8 + 0.2 * p}) translateY(${(1 - p) * 40}px)`,
          }}
        >
          GDP
        </div>
      </div>
      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
        <line
          x1="270" y1="1150" x2="810" y2="1060" stroke={theme.colors.primary} strokeWidth="14" strokeLinecap="round"
          pathLength={1} strokeDasharray="1" strokeDashoffset={1 - Math.min(1, Math.max(0, strike))}
          style={{ filter: `drop-shadow(0 0 18px ${theme.colors.glow})` }}
        />
      </svg>
      <Stack top={1290} gap={0}>
        <WordReveal text="में नहीं" size={64} weight={500} color={theme.colors.textDim} delay={28} />
      </Stack>
    </>
  );
};

export const Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const gp = usePop(0);
  const move = interpolate(frame, [T(5.55), T(5.55) + 30], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const cy = interpolate(move, [0, 1], [560, 470]);
  const sc = interpolate(move, [0, 1], [1, 0.66]);
  const float = Math.sin(frame / 30) * 6;
  return (
    <SceneShell>
      <div
        style={{
          position: "absolute", left: 150, top: cy - 390 + float, width: 780, height: 780,
          opacity: Math.min(1, gp), transform: `scale(${sc * (0.9 + 0.1 * gp)})`,
        }}
      >
        <Globe size={780} />
      </div>

      {/* Phase A — the question (0 → 5.7s) */}
      <Phase from={0} dur={T(5.7)} exit={8}>
        <Stack top={1030} gap={6}>
          <WordReveal text="क्या भारत की बढ़ती अर्थव्यवस्था" size={74} delay={6} />
          <WordReveal text="दुनिया की [[ताकत का संतुलन]]" size={80} delay={T(2.4)} />
          <WordReveal text="बदल सकती है?" size={74} delay={T(4.0)} />
        </Stack>
      </Phase>

      {/* Phase B1 — GDP struck out */}
      <Phase from={T(5.7)} dur={T(8.1) - T(5.7)} exit={8}>
        <GdpBlock />
      </Phase>

      {/* Phase B2 — three things */}
      <Phase from={T(8.1)} dur={T(10.7) - T(8.1)} exit={0}>
        <Stack top={900} gap={0}>
          <WordReveal text="[[तीन]] बड़ी चीजें" size={112} />
        </Stack>
        <div style={{ position: "absolute", left: 0, right: 0, top: 1190, display: "flex", justifyContent: "center", gap: 50 }}>
          <NumberBadge n="01" delay={14} />
          <NumberBadge n="02" delay={22} />
          <NumberBadge n="03" delay={30} />
        </div>
      </Phase>
    </SceneShell>
  );
};
