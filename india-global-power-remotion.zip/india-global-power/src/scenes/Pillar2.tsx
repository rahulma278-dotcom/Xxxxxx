import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { at } from "../timing";
import { Eyebrow, Phase, Pop, SceneShell, Stack, WordReveal, clamp } from "../components/Text";

const S = 2;
const T = (t: number) => at(S, t);

const CX = 540;
const CY = 960;
const R1 = 290;
const R2 = 430;
const pos = (ang: number, r: number) => ({
  x: CX + r * Math.cos((ang * Math.PI) / 180),
  y: CY + r * Math.sin((ang * Math.PI) / 180),
});

const SATS = [
  { label: "व्यापार", ang: -90, t: 26.5 },
  { label: "Technology", ang: 30, t: 27.4 },
  { label: "साझेदारियां", ang: 150, t: 28.6 },
];
const RING = Array.from({ length: 8 }).map((_, i) => -67.5 + i * 45);
const RIPPLE_AT = T(30.15);

const Pill: React.FC<{ label: string; x: number; y: number; delay: number }> = ({ label, x, y, delay }) => {
  const frame = useCurrentFrame();
  const amt = interpolate(frame, [delay, delay + 5, delay + 34, delay + 44], [0, 1, 1, 0], clamp);
  return (
    <div style={{ position: "absolute", left: x - 135, top: y - 50, width: 270, height: 100 }}>
      <Pop delay={delay} y={24} from={0.85} style={{ width: "100%", height: "100%" }}>
        <div
          style={{
            position: "relative", width: "100%", height: "100%", borderRadius: 50,
            background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassBorder}`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: theme.fonts.display, fontSize: 44, fontWeight: 700, letterSpacing: 0,
            lineHeight: 1.3, color: theme.colors.text, boxShadow: "0 30px 60px -25px rgba(0,0,0,0.7)",
          }}
        >
          {label}
          <div
            style={{
              position: "absolute", inset: 0, borderRadius: 50, opacity: amt,
              border: `2.5px solid ${theme.colors.primary}`, boxShadow: `0 0 50px ${theme.colors.glow}`,
            }}
          />
        </div>
      </Pop>
    </div>
  );
};

const Hub: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const dim = interpolate(frame, [T(35.0), T(35.0) + 14], [1, 0.3], clamp);
  const centerP = spring({ frame: frame - T(25.0), fps, config: theme.spring.bouncy });
  const breathe = 1 + Math.sin(frame / 24) * 0.015;
  const orbitIn = interpolate(frame, [T(24.8), T(24.8) + 25], [0, 1], { easing: theme.ease.out, ...clamp });
  return (
    <div style={{ position: "absolute", inset: 0, opacity: dim }}>
      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
        <circle cx={CX} cy={CY} r={R1} fill="none" stroke={theme.colors.accent} strokeOpacity={0.14 * orbitIn} strokeWidth="2" />
        <circle cx={CX} cy={CY} r={R2} fill="none" stroke={theme.colors.accent} strokeOpacity={0.1 * orbitIn} strokeWidth="2" strokeDasharray="4 14" />

        {SATS.map((s, i) => {
          const p = spring({ frame: frame - T(s.t) + 6, fps, config: theme.spring.smooth });
          const q = pos(s.ang, R1);
          return (
            <line
              key={`sp${i}`} x1={CX} y1={CY} x2={q.x} y2={q.y}
              stroke={theme.colors.accent} strokeOpacity="0.55" strokeWidth="3" strokeLinecap="round"
              pathLength={1} strokeDasharray="1" strokeDashoffset={1 - Math.min(1, Math.max(0, p))}
            />
          );
        })}

        {RING.map((a, i) => {
          const p = spring({ frame: frame - RIPPLE_AT - i * 4, fps, config: theme.spring.smooth });
          const q = pos(a, R2);
          const pp = Math.min(1, Math.max(0, p));
          return (
            <g key={`rg${i}`}>
              <line
                x1={CX} y1={CY} x2={q.x} y2={q.y} stroke={theme.colors.accent} strokeOpacity="0.3" strokeWidth="2"
                pathLength={1} strokeDasharray="1" strokeDashoffset={1 - pp}
              />
              <circle cx={q.x} cy={q.y} r={15 * pp} fill={theme.colors.accent} />
            </g>
          );
        })}

        {[0, 1, 2].map((k) => {
          if (frame < RIPPLE_AT + k * 30) return null;
          const ph = ((frame - RIPPLE_AT - k * 30) % 90) / 90;
          const r = interpolate(ph, [0, 1], [120, R2 + 40], { easing: theme.ease.out, ...clamp });
          return (
            <circle key={`rp${k}`} cx={CX} cy={CY} r={r} fill="none" stroke={theme.colors.accent} strokeOpacity={(1 - ph) * 0.35} strokeWidth="3" />
          );
        })}
      </svg>

      <div
        style={{
          position: "absolute", left: CX - 110, top: CY - 110, width: 220, height: 220, borderRadius: "50%",
          background: theme.colors.glass, border: `2.5px solid ${theme.colors.accent}`,
          boxShadow: `0 0 60px ${theme.colors.line}`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: theme.fonts.display, fontSize: 64, fontWeight: 700, letterSpacing: 0, lineHeight: 1.3,
          color: theme.colors.text, opacity: Math.min(1, Math.max(0, centerP)),
          transform: `scale(${Math.max(0, centerP) * breathe})`,
        }}
      >
        भारत
      </div>

      {SATS.map((s) => {
        const q = pos(s.ang, R1);
        return <Pill key={s.label} label={s.label} x={q.x} y={q.y} delay={T(s.t)} />;
      })}
    </div>
  );
};

export const Pillar2: React.FC = () => (
  <SceneShell>
    <Stack top={290} gap={14}>
      <Eyebrow text="02 / 03" delay={T(23.7)} />
      <WordReveal text="वैश्विक भागीदारी" size={118} delay={T(23.92)} per={4} />
    </Stack>

    <Hub />

    <Phase from={T(30.15)} dur={T(35.0) - T(30.15)} exit={8}>
      <Stack top={1470} gap={2}>
        <WordReveal text="देशों के आर्थिक फैसलों में" size={50} weight={500} color={theme.colors.textDim} />
        <WordReveal text="[[बढ़ती भूमिका]]" size={92} delay={10} />
      </Stack>
    </Phase>

    <Phase from={T(35.1)} dur={T(36.9) - T(35.1)} exit={0}>
      <Stack top={1490} gap={0}>
        <WordReveal text="लेकिन [[तीसरी]] बात…" size={96} />
      </Stack>
    </Phase>
  </SceneShell>
);
