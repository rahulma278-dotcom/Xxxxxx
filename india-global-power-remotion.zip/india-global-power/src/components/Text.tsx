import React from "react";
import { AbsoluteFill, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

export const usePop = (delay = 0, cfg: { damping: number; stiffness: number; mass: number } = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: cfg });
};

// Entrance: opacity + translate + scale together
export const Pop: React.FC<{
  delay?: number; y?: number; x?: number; from?: number;
  style?: React.CSSProperties; children: React.ReactNode;
}> = ({ delay = 0, y = 40, x = 0, from = 0.94, style, children }) => {
  const p = usePop(delay);
  return (
    <div
      style={{
        opacity: Math.min(1, Math.max(0, p * 1.2)),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${from + (1 - from) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// Exit wrapper — faster than entrances (~8–10 frames)
export const ExitWrap: React.FC<{ n?: number; children: React.ReactNode }> = ({ n = 8, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t =
    n > 1
      ? interpolate(frame, [durationInFrames - n, durationInFrames - 1], [0, 1], {
          easing: theme.ease.in, ...clamp,
        })
      : 0;
  return (
    <AbsoluteFill style={{ opacity: 1 - t, transform: `translateY(${-28 * t}px) scale(${1 + 0.015 * t})` }}>
      {children}
    </AbsoluteFill>
  );
};

export const SceneShell: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <ExitWrap n={10}>{children}</ExitWrap>
);

// A timed sub-block inside a scene (local frames restart at 0 inside it)
export const Phase: React.FC<{ from: number; dur: number; exit?: number; children: React.ReactNode }> = ({
  from, dur, exit = 8, children,
}) => (
  <Sequence from={from} durationInFrames={dur} layout="none">
    <ExitWrap n={exit}>{children}</ExitWrap>
  </Sequence>
);

// Vertical stack positioned by pixel `top`
export const Stack: React.FC<{ top: number; gap?: number; children: React.ReactNode }> = ({
  top, gap = 16, children,
}) => (
  <div
    style={{
      position: "absolute", left: 0, right: 0, top,
      display: "flex", flexDirection: "column", alignItems: "center", gap,
    }}
  >
    {children}
  </div>
);

type Tok = { w: string; hl: boolean };
// "[[ ]]" marks highlighted words. Words split on spaces only (Devanagari-safe).
const parse = (text: string): Tok[] => {
  const out: Tok[] = [];
  const re = /\[\[(.+?)\]\]/g;
  let last = 0;
  let m: RegExpExecArray | null;
  const push = (s: string, hl: boolean) => s.split(" ").filter(Boolean).forEach((w) => out.push({ w, hl }));
  while ((m = re.exec(text))) {
    push(text.slice(last, m.index), false);
    push(m[1], true);
    last = m.index + m[0].length;
  }
  push(text.slice(last), false);
  return out;
};

// Word-by-word stagger. Never per-letter (breaks Hindi conjuncts / matras).
export const WordReveal: React.FC<{
  text: string; size: number; delay?: number; per?: number; weight?: number;
  color?: string; maxWidth?: number;
}> = ({ text, size, delay = 0, per = 3, weight = 700, color = theme.colors.text, maxWidth = 940 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const toks = parse(text);
  return (
    <div
      style={{
        display: "flex", flexWrap: "wrap", justifyContent: "center",
        columnGap: Math.round(size * 0.28), rowGap: Math.round(size * 0.06),
        maxWidth, fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight,
        lineHeight: 1.3, letterSpacing: 0, color, textAlign: "center",
      }}
    >
      {toks.map((t, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const u = spring({ frame: frame - delay - i * per - 6, fps, config: theme.spring.smooth });
        return (
          <span
            key={i}
            style={{
              position: "relative", display: "inline-block",
              opacity: Math.min(1, Math.max(0, p * 1.2)),
              transform: `translateY(${(1 - p) * 34}px) scale(${0.94 + 0.06 * p})`,
              color: t.hl ? theme.colors.primary : undefined,
              textShadow: t.hl ? `0 0 44px ${theme.colors.glow}` : undefined,
            }}
          >
            {t.w}
            {t.hl ? (
              <span
                style={{
                  position: "absolute", left: 0, bottom: 2, width: "100%",
                  height: Math.max(4, Math.round(size * 0.05)), borderRadius: 8,
                  background: theme.colors.primary, opacity: 0.85,
                  transformOrigin: "0% 50%", transform: `scaleX(${Math.min(1, Math.max(0, u))})`,
                }}
              />
            ) : null}
          </span>
        );
      })}
    </div>
  );
};

export const Eyebrow: React.FC<{ text: string; delay?: number }> = ({ text, delay = 0 }) => (
  <Pop delay={delay} y={20}>
    <div
      style={{
        fontFamily: theme.fonts.display, fontSize: 42, fontWeight: 500, letterSpacing: 0,
        color: theme.colors.accent, fontVariantNumeric: "tabular-nums",
        display: "flex", alignItems: "center", gap: 20,
      }}
    >
      <span style={{ width: 64, height: 3, background: theme.colors.accent, opacity: 0.7, borderRadius: 2 }} />
      {text}
      <span style={{ width: 64, height: 3, background: theme.colors.accent, opacity: 0.7, borderRadius: 2 }} />
    </div>
  </Pop>
);
