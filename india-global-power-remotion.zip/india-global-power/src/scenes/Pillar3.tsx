import React from "react";
import { theme } from "../theme";
import { at } from "../timing";
import { ListCard } from "../components/Cards";
import { Eyebrow, Phase, SceneShell, Stack, WordReveal } from "../components/Text";

const S = 3;
const T = (t: number) => at(S, t);

const ROWS = [
  { icon: "person", label: "रोजगार", t: 38.8 },
  { icon: "coin", label: "प्रति व्यक्ति आय", t: 39.6 },
  { icon: "bridge", label: "बुनियादी ढांचा", t: 41.2 },
  { icon: "import", label: "आयात पर निर्भरता", t: 42.6 },
] as const;
const END_T = 43.45;

export const Pillar3: React.FC = () => (
  <SceneShell>
    <Stack top={290} gap={14}>
      <Eyebrow text="03 / 03" delay={T(36.95)} />
      <WordReveal text="चुनौतियां" size={124} delay={T(37.15)} per={4} />
    </Stack>

    {ROWS.map((r, i) => (
      <ListCard
        key={r.label}
        index={i}
        top={600 + i * 216}
        height={186}
        delay={T(r.t)}
        icon={r.icon}
        label={r.label}
        activeFrom={T(r.t)}
        activeTo={T(i < 3 ? ROWS[i + 1].t : END_T)}
      />
    ))}

    <Phase from={T(END_T)} dur={T(46.9) - T(END_T)} exit={0}>
      <Stack top={1520} gap={0}>
        <WordReveal text="अभी भी [[मायने]] रखती हैं" size={74} />
      </Stack>
    </Phase>
  </SceneShell>
);
