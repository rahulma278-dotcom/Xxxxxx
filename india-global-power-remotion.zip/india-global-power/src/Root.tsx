import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { TOTAL } from "./timing";
import { theme } from "./theme";

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={TOTAL}
    fps={theme.video.fps}
    width={theme.video.width}
    height={theme.video.height}
  />
);
