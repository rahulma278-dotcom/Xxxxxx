import React from "react";
import { Audio, Sequence, getRemotionEnvironment, staticFile } from "remotion";
import { SFX } from "../sfx";
import { sec } from "../timing";
import { theme } from "../theme";

// SFX only (no music, no voiceover). Starts 2 frames BEFORE the visual lands.
export const SfxTrack: React.FC = () => (
  <>
    {SFX.map((e, i) => (
      <Sequence key={i} from={Math.max(0, sec(e.t) - 2)} durationInFrames={sec(1)}>
        <Audio src={staticFile(`sfx/${e.file}.wav`)} volume={e.v} playbackRate={e.r ?? 1} />
      </Sequence>
    ))}
  </>
);

// Studio preview only: plays public/voiceover.mp3 for sync checks. Never part of a render.
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  if (!theme.flags.previewVoiceover || !env.isStudio || env.isRendering) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
