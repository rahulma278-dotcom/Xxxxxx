import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

// Layer 1 — animated mesh + faint geopolitical grid (never a flat background)
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill
      style={{ background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 100%)` }}
    >
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -520, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.accent}30, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1100, height: 1100, borderRadius: "50%",
          bottom: -520, right: -420 - d2, filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.primary}22, transparent 65%)`,
        }}
      />
      <div
        style={{
          position: "absolute", inset: 0,
          backgroundImage: `linear-gradient(rgba(91,168,255,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(91,168,255,0.07) 1px, transparent 1px)`,
          backgroundSize: "90px 90px",
          backgroundPosition: `${frame * 0.25}px ${frame * 0.25}px`,
          WebkitMaskImage: "radial-gradient(ellipse at 50% 45%, black 15%, transparent 72%)",
          maskImage: "radial-gradient(ellipse at 50% 45%, black 15%, transparent 72%)",
        }}
      />
    </AbsoluteFill>
  );
};

// Layer 4 — colour grade (above content, below grain)
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{ backgroundColor: theme.colors.accent, mixBlendMode: "soft-light", opacity: 0.16 }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))",
      }}
    />
  </AbsoluteFill>
);

// Layer 5a — procedural film grain
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.07, mixBlendMode: "overlay",
      }}
    />
  );
};

// Layer 5b — vignette (topmost)
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.38) 100%)",
    }}
  />
);
