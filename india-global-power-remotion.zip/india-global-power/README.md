# India Global Power — 9:16 Remotion project (Dark Geopolitics)

1080×1920 · 30fps · ~65.7s · Hindi on-screen text (Hind font) · SFX only

## Run
1. `npm install`
2. `npx remotion studio src/index.ts`   (live preview)
3. Final MP4 (when ready): `npx remotion render src/index.ts Main out/video.mp4`

## Optional
- Voiceover for preview sync: put the MP3 at `public/voiceover.mp3`
  (Studio only, never rendered; turn off via `theme.flags.previewVoiceover = false` in `src/theme.ts`).
- Logo: put it in `public/` and set `theme.flags.logoFile = "logo.png"` in `src/theme.ts`.
- Re-generate SFX: `npm run sfx` (outputs to `public/sfx/`).

## Where to tweak
- `src/timing.ts` scene boundaries (from the SRT) · `src/sfx.ts` SFX cue sheet · `src/theme.ts` colours/fonts/springs.
