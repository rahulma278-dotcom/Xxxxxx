import React from "react";
import { interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { clamp } from "./Text";

// Scene transition: dark panel with amber leading edge sweeps across; the cut hides behind it.
export const Sweep: React.FC<{ cut: number }> = ({ cut }) => {
  const frame = useCurrentFrame();
  const { width } = useVideoConfig();
  if (frame < cut - 9 || frame > cut + 9) return null;
  const inP = interpolate(frame, [cut - 9, cut], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const outP = interpolate(frame, [cut, cut + 9], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const x = frame < cut ? -width * (1 - inP) : width * outP;
  return (
    <div
      style={{
        position: "absolute", top: 0, left: 0, width, height: "100%",
        transform: `translateX(${x}px)`,
        background: `linear-gradient(90deg, ${theme.colors.bg}, ${theme.colors.bgAlt})`,
      }}
    >
      <div
        style={{
          position: "absolute", right: 0, top: 0, width: 10, height: "100%",
          background: theme.colors.primary, boxShadow: `0 0 60px 10px ${theme.colors.glow}`,
        }}
      />
    </div>
  );
};
