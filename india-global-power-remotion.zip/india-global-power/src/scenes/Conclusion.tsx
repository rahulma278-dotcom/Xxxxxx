import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { at } from "../timing";
import { Phase, Pop, SceneShell, Stack, WordReveal, clamp } from "../components/Text";

const S = 4;
const T = (t: number) => at(S, t);

// Balance scale: beam wobbles (spring overshoot) and settles tilted toward India
const Balance: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const w = spring({ frame: frame - 24, fps, config: theme.spring.wobble });
  const a = (-9 * w * Math.PI) / 180;
  const px = 450;
  const py = 180;
  const half = 330;
  const lx = px - half * Math.cos(a);
  const ly = py - half * Math.sin(a);
  const rx = px + half * Math.cos(a);
  const ry = py + half * Math.sin(a);
  const drop = 170;
  const pan = (ex: number, ey: number) => (
    <>
      <path d={`M ${ex} ${ey} L ${ex - 100} ${ey + drop} M ${ex} ${ey} L ${ex + 100} ${ey + drop}`} stroke={theme.colors.accent} strokeOpacity="0.6" strokeWidth="3" fill="none" strokeLinecap="round" />
      <path d={`M ${ex - 100} ${ey + drop} Q ${ex} ${ey + drop + 54} ${ex + 100} ${ey + drop}`} stroke={theme.colors.accent} strokeWidth="5" fill={theme.colors.glass} strokeLinecap="round" />
    </>
  );
  return (
    <svg width={900} height={760} viewBox="0 0 900 760">
      <path d={`M ${px} ${py} V 640 M 300 690 H 600 L 560 640 H 340 Z`} stroke={theme.colors.accent} strokeWidth="5" fill={theme.colors.glass} strokeLinejoin="round" strokeLinecap="round" />
      <path d={`M ${lx} ${ly} L ${rx} ${ry}`} stroke={theme.colors.text} strokeWidth="11" strokeLinecap="round" />
      {pan(lx, ly)}
      {pan(rx, ry)}
      <circle cx={lx} cy={ly + drop - 48} r={46} fill={theme.colors.accent} fillOpacity="0.9" style={{ filter: `drop-shadow(0 0 22px ${theme.colors.line})` }} />
      <circle cx={rx} cy={ry + drop - 28} r={26} fill={theme.colors.textDim} fillOpacity="0.8" />
      <circle cx={px} cy={py} r={17} fill={theme.colors.text} />
      <text x={lx} y={ly + drop + 130} textAnchor="middle" fill={theme.colors.text} fontFamily={theme.fonts.display} fontSize={54} fontWeight={700} letterSpacing={0}>
        भारत
      </text>
      <text x={rx} y={ry + drop + 130} textAnchor="middle" fill={theme.colors.textDim} fontFamily={theme.fonts.display} fontSize={54} fontWeight={500} letterSpacing={0}>
        दुनिया
      </text>
    </svg>
  );
};

const Potential: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const arrow = spring({ frame: frame - 104, fps, config: theme.spring.smooth });
  const ap = Math.min(1, Math.max(0, arrow));
  const pulse = interpolate(Math.sin(frame / 10), [-1, 1], [0.4, 0.9]);
  return (
    <>
      <Stack top={330} gap={0}>
        <WordReveal text="लेकिन असर इस पर निर्भर करेगा" size={62} weight={500} color={theme.colors.textDim} />
      </Stack>

      <div style={{ position: "absolute", left: 140, top: 760, width: 800, height: 170 }}>
        <Pop delay={64} y={40} style={{ width: "100%", height: "100%" }}>
          <div
            style={{
              width: "100%", height: "100%", borderRadius: 40, boxSizing: "border-box",
              background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassBorder}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: theme.fonts.display, fontSize: 70, fontWeight: 700, letterSpacing: 0, lineHeight: 1.3,
              color: theme.colors.text, boxShadow: "0 40px 80px -30px rgba(0,0,0,0.7)",
            }}
          >
            आर्थिक क्षमता
          </div>
        </Pop>
      </div>

      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
        <path d="M 540 950 V 1105" stroke={theme.colors.accent} strokeWidth="6" strokeLinecap="round" fill="none" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - ap} />
        <path d="M 508 1076 L 540 1110 L 572 1076" stroke={theme.colors.accent} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity={ap} />
      </svg>

      <div style={{ position: "absolute", left: 140, top: 1135, width: 800, height: 250 }}>
        <Pop delay={120} y={50} style={{ width: "100%", height: "100%" }}>
          <div
            style={{
              position: "relative", width: "100%", height: "100%", borderRadius: 40, boxSizing: "border-box",
              background: theme.colors.glass, border: `1.5px solid ${theme.colors.glassBorder}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 0,
              boxShadow: "0 40px 80px -30px rgba(0,0,0,0.7)",
            }}
          >
            <WordReveal text="कितनी अच्छी तरह" size={50} weight={500} color={theme.colors.textDim} delay={126} />
            <WordReveal text="[[इस्तेमाल]]" size={96} delay={136} />
            <div
              style={{
                position: "absolute", inset: 0, borderRadius: 40, border: `2.5px solid ${theme.colors.primary}`,
                opacity: pulse * 0.6, boxShadow: `0 0 50px ${theme.colors.glow}`,
              }}
            />
          </div>
        </Pop>
      </div>
    </>
  );
};

export const Conclusion: React.FC = () => (
  <SceneShell>
    {/* A — भारत का बढ़ता आर्थिक प्रभाव */}
    <Phase from={0} dur={T(50.1)} exit={8}>
      <Stack top={760} gap={6}>
        <WordReveal text="इसलिए" size={60} weight={500} color={theme.colors.textDim} delay={4} />
        <WordReveal text="भारत का बढ़ता" size={100} delay={12} />
        <WordReveal text="[[आर्थिक प्रभाव]]" size={120} delay={30} />
      </Stack>
    </Phase>

    {/* B — शक्ति संतुलन */}
    <Phase from={T(50.1)} dur={T(53.8) - T(50.1)} exit={8}>
      <Stack top={290} gap={0}>
        <WordReveal text="दुनिया का [[शक्ति संतुलन]]" size={100} delay={4} />
      </Stack>
      <div style={{ position: "absolute", left: 90, top: 640 }}>
        <Pop delay={6} y={40}>
          <Balance />
        </Pop>
      </div>
    </Phase>

    {/* C — क्षमता → इस्तेमाल */}
    <Phase from={T(53.8)} dur={T(60.8) - T(53.8)} exit={0}>
      <Potential />
    </Phase>
  </SceneShell>
);
