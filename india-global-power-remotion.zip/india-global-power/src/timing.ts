// All timing is derived from the SRT (seconds) — one place to adjust.
import { theme } from "./theme";

export const FPS = theme.video.fps;
export const sec = (t: number) => Math.round(t * FPS);

// Scene boundaries (seconds), aligned to SRT cue / phrase starts.
// 0 Hook | 1 आर्थिक ताकत | 2 वैश्विक भागीदारी | 3 चुनौतियां | 4 निष्कर्ष | 5 CTA
export const BOUNDS = [0, 10.7, 23.5, 36.9, 46.9, 60.8, 65.67];

export const sceneFrom = (i: number) => sec(BOUNDS[i]);
export const sceneDur = (i: number) => sec(BOUNDS[i + 1]) - sec(BOUNDS[i]);
export const TOTAL = sec(BOUNDS[BOUNDS.length - 1]);
export const CUT_FRAMES = BOUNDS.slice(1, -1).map(sec);

// absolute time (s) -> local frame inside scene i
export const at = (scene: number, t: number) => sec(t) - sec(BOUNDS[scene]);
