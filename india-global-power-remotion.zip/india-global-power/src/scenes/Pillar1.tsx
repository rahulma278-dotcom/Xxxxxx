import React from "react";
import { theme } from "../theme";
import { at } from "../timing";
import { ListCard } from "../components/Cards";
import { Eyebrow, Phase, SceneShell, Stack, WordReveal } from "../components/Text";

const S = 1;
const T = (t: number) => at(S, t);

const CARDS = [
  { icon: "market", label: "विशाल बाजार", t: 13.45 },
  { icon: "digital", label: "Digital Ecosystem", t: 15.3 },
  { icon: "factory", label: "Manufacturing में निवेश", t: 17.2 },
] as const;
const HUB_T = 19.35;

export const Pillar1: React.FC = () => (
  <SceneShell>
    <Stack top={290} gap={14}>
      <Eyebrow text="01 / 03" delay={T(11.0)} />
      <WordReveal text="आर्थिक ताकत" size={124} delay={T(11.2)} per={4} />
    </Stack>

    {CARDS.map((c, i) => (
      <ListCard
        key={c.label}
        index={i}
        top={640 + i * 234}
        delay={T(c.t)}
        icon={c.icon}
        label={c.label}
        labelSize={i === 2 ? 50 : 56}
        activeFrom={T(c.t)}
        activeTo={T(i < 2 ? CARDS[i + 1].t : HUB_T)}
      />
    ))}

    <Phase from={T(HUB_T)} dur={T(23.5) - T(HUB_T)} exit={0}>
      <Stack top={1400} gap={4}>
        <WordReveal text="दुनिया की कंपनियों के लिए" size={52} weight={500} color={theme.colors.textDim} />
        <WordReveal text="[[अहम केंद्र]]" size={104} delay={10} />
      </Stack>
    </Phase>
  </SceneShell>
);
