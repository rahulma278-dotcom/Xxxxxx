public/voiceover.mp3  -> optional, Studio preview only (not rendered)
public/logo.png       -> optional, then set theme.flags.logoFile = "logo.png"
public/sfx/*.wav      -> synthesized SFX kit (whoosh, swipe, pop, click, chime)
