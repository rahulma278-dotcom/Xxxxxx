// Deterministic SFX synthesis -> public/sfx/*.wav (16-bit mono, 44.1 kHz). No downloads.
// Kit: whoosh, swipe, pop, click, chime. Short, clean, professional UI/motion-graphics sounds.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(OUT, { recursive: true });

let seed = 1337;
const rnd = () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noise = () => rnd() * 2 - 1;

class Biquad {
  constructor() { this.x1 = this.x2 = this.y1 = this.y2 = 0; this.c = [1, 0, 0, 0, 0]; }
  set(type, fc, q) {
    const w = (2 * Math.PI * fc) / SR, cos = Math.cos(w), alpha = Math.sin(w) / (2 * q);
    let b0, b1, b2;
    if (type === "lp") { b0 = (1 - cos) / 2; b1 = 1 - cos; b2 = (1 - cos) / 2; }
    else if (type === "hp") { b0 = (1 + cos) / 2; b1 = -(1 + cos); b2 = (1 + cos) / 2; }
    else { b0 = alpha; b1 = 0; b2 = -alpha; } // band-pass
    const a0 = 1 + alpha, a1 = -2 * cos, a2 = 1 - alpha;
    this.c = [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];
  }
  p(x) {
    const [b0, b1, b2, a1, a2] = this.c;
    const y = b0 * x + b1 * this.x1 + b2 * this.x2 - a1 * this.y1 - a2 * this.y2;
    this.x2 = this.x1; this.x1 = x; this.y2 = this.y1; this.y1 = y;
    return y;
  }
}

const mk = (dur) => new Float32Array(Math.round(dur * SR));
const lowpass = (buf, fc) => { const f = new Biquad(); f.set("lp", fc, 0.707); for (let i = 0; i < buf.length; i++) buf[i] = f.p(buf[i]); };
// very short, dark reverb (3 taps, low-passed)
const reverb = (buf) => {
  const taps = [[0.043, 0.16], [0.071, 0.11], [0.113, 0.07]];
  const dry = Float32Array.from(buf);
  for (const [d, g] of taps) { const o = Math.round(d * SR); for (let i = o; i < buf.length; i++) buf[i] += dry[i - o] * g; }
};
const finish = (buf, peak = 0.9) => {
  lowpass(buf, 9000);
  reverb(buf);
  const fade = Math.round(0.012 * SR);
  for (let i = 0; i < fade; i++) buf[buf.length - 1 - i] *= i / fade;
  let m = 0; for (const v of buf) m = Math.max(m, Math.abs(v));
  const g = peak / (m || 1);
  for (let i = 0; i < buf.length; i++) buf[i] *= g;
  return buf;
};

const sounds = {
  // pop: fast pitch-dropping sine + short envelope
  pop() {
    const b = mk(0.22); let ph = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR, f = 170 + 560 * Math.exp(-t / 0.035);
      ph += (2 * Math.PI * f) / SR;
      const env = Math.min(1, t / 0.003) * Math.exp(-t / 0.055);
      b[i] = (Math.sin(ph) + 0.2 * Math.sin(2 * ph)) * env;
    }
    return finish(b);
  },
  // click: high-passed noise burst + tiny tick tone
  click() {
    const b = mk(0.12), hp = new Biquad(); hp.set("hp", 2600, 0.8); let ph = 0;
    for (let i = 0; i < b.length; i++) {
      const t = i / SR; ph += (2 * Math.PI * 1900) / SR;
      b[i] = hp.p(noise()) * Math.exp(-t / 0.011) + 0.3 * Math.sin(ph) * Math.exp(-t / 0.008);
    }
    return finish(b);
  },
  // whoosh: band-passed noise, sweep up, fade in/out (<= 0.8 s)
  whoosh() {
    const dur = 0.7, b = mk(dur), bp = new Biquad();
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      if (i % 32 === 0) bp.set("bp", 380 * Math.pow(9, Math.min(1, t / 0.55)), 1.1);
      const env = t < 0.22 ? Math.pow(t / 0.22, 1.6) : Math.exp(-(t - 0.22) / 0.17);
      b[i] = bp.p(noise()) * env;
    }
    return finish(b);
  },
  // swipe: shorter, brighter transition whoosh
  swipe() {
    const b = mk(0.4), bp = new Biquad();
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      if (i % 32 === 0) bp.set("bp", 1100 * Math.pow(4.5, Math.min(1, t / 0.3)), 1.4);
      const env = t < 0.09 ? Math.pow(t / 0.09, 1.4) : Math.exp(-(t - 0.09) / 0.1);
      b[i] = bp.p(noise()) * env;
    }
    return finish(b);
  },
  // chime: soft pluck with a few overtones and a short decay (logo)
  chime() {
    const b = mk(0.5), parts = [[880, 1, 0.13], [1318.5, 0.5, 0.1], [1760, 0.3, 0.08], [2349, 0.14, 0.05]];
    for (let i = 0; i < b.length; i++) {
      const t = i / SR; let v = 0;
      for (const [f, a, tau] of parts) v += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / tau);
      b[i] = v * Math.min(1, t / 0.004);
    }
    return finish(b);
  },
};

const wav = (buf) => {
  const n = buf.length, out = Buffer.alloc(44 + n * 2);
  out.write("RIFF", 0); out.writeUInt32LE(36 + n * 2, 4); out.write("WAVEfmt ", 8);
  out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22);
  out.writeUInt32LE(SR, 24); out.writeUInt32LE(SR * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34);
  out.write("data", 36); out.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) out.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(buf[i] * 32767))), 44 + i * 2);
  return out;
};

for (const [name, fn] of Object.entries(sounds)) {
  const buf = fn();
  fs.writeFileSync(path.join(OUT, `${name}.wav`), wav(buf));
  let peak = 0, clipped = 0;
  for (const v of buf) { peak = Math.max(peak, Math.abs(v)); if (Math.abs(v) >= 1) clipped++; }
  console.log(`${name}.wav  ${(buf.length / SR).toFixed(2)}s  peak ${peak.toFixed(2)}  clipped ${clipped}`);
}
