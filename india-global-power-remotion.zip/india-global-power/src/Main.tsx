import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { CUT_FRAMES, sceneDur, sceneFrom } from "./timing";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { Sweep } from "./components/Sweep";
import { PreviewAudio, SfxTrack } from "./components/Sfx";
import { Hook } from "./scenes/Hook";
import { Pillar1 } from "./scenes/Pillar1";
import { Pillar2 } from "./scenes/Pillar2";
import { Pillar3 } from "./scenes/Pillar3";
import { Conclusion } from "./scenes/Conclusion";
import { Cta } from "./scenes/Cta";

const SCENES = [Hook, Pillar1, Pillar2, Pillar3, Conclusion, Cta];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
    {/* 1 background mesh */}
    <BgMesh />
    {/* 2–3 assets + graphics/type (scenes) */}
    {SCENES.map((Scene, i) => (
      <Sequence key={i} from={sceneFrom(i)} durationInFrames={sceneDur(i)}>
        <Scene />
      </Sequence>
    ))}
    {CUT_FRAMES.map((cut) => (
      <Sweep key={cut} cut={cut} />
    ))}
    {/* 4 grade → 5 grain + vignette */}
    <Grade />
    <Grain />
    <Vignette />
    {/* audio: SFX always; voiceover only in Studio preview */}
    <SfxTrack />
    <PreviewAudio />
  </AbsoluteFill>
);
