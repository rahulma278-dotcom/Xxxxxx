import React from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Pop, SceneShell, Stack, WordReveal, clamp } from "../components/Text";
import { Spark } from "../components/Spark";

const FOLLOW = 46; // 62.32s
const MARK = 78; // 63.4s

export const Cta: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const press = spring({ frame: frame - (FOLLOW + 16), fps, config: theme.spring.bouncy });
  const btnScale = 1 - 0.06 * Math.sin(Math.min(1, Math.max(0, press)) * Math.PI);
  const ripple = interpolate(frame, [FOLLOW + 16, FOLLOW + 36], [0, 1], { easing: theme.ease.out, ...clamp });
  const breathe = 1 + Math.sin(frame / 22) * 0.012;
  const logo = theme.flags.logoFile;
  const logoP = spring({ frame: frame - MARK, fps, config: theme.spring.bouncy });
  return (
    <SceneShell>
      <Stack top={520} gap={0}>
        <WordReveal text="ऐसी ही [[global analysis]] के लिए" size={68} delay={4} />
      </Stack>

      <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
        <Pop delay={FOLLOW} y={50} from={0.85}>
          <div style={{ position: "relative", transform: `scale(${btnScale * breathe})` }}>
            <div
              style={{
                position: "absolute", inset: -ripple * 40, borderRadius: 100, opacity: (1 - ripple) * 0.5,
                border: `3px solid ${theme.colors.accent}`,
              }}
            />
            <div
              style={{
                width: 560, height: 150, borderRadius: 75, boxSizing: "border-box",
                background: `${theme.colors.accent}26`, border: `3px solid ${theme.colors.accent}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontFamily: theme.fonts.display, fontSize: 64, fontWeight: 700, letterSpacing: 0, lineHeight: 1.3,
                color: theme.colors.text,
              }}
            >
              follow करें
            </div>
          </div>
        </Pop>
      </div>

      <div
        style={{
          position: "absolute", left: 0, right: 0, top: 1090,
          display: "flex", flexDirection: "column", alignItems: "center", gap: 34,
        }}
      >
        {logo ? (
          <div style={{ width: 200, height: 200, transform: `scale(${Math.max(0, logoP) * breathe})`, filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
            <Img src={staticFile(logo)} style={{ width: "100%", height: "100%", objectFit: "contain" }} />
          </div>
        ) : (
          <Spark size={190} delay={MARK} />
        )}
        <WordReveal text="Global Realism" size={116} delay={MARK + 8} per={5} />
      </div>
    </SceneShell>
  );
};
